<style>
    .nav-link:hover{
        background-color: #B81F57;
        color: white!important;
        border-radius: 20%;
    }
    .nav-link{
        transition: background-color 1s;
        border-radius:20%;
    }
</style><?php /**PATH C:\Users\Usuario\OneDrive\Escritorio\Uniserver2.0\UniServerZ\www\GureTabadul\GureTabadul\Laravel\resources\views/layout/estilos.blade.php ENDPATH**/ ?>