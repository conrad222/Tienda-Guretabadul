
<?php $__env->startSection('Titulo', 'Tienda'); ?>
<?php $__env->startSection('contenido'); ?>
<?php $__env->startSection('estilos'); ?>
<?php $__env->stopSection(); ?>
<p>Holaaaa</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.masterpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gorka\Desktop\clase\2DAW\fase4\mikel\UniServerZ\www\TrabajoTiendaPlotters\Laravel\resources\views/secciones/tienda.blade.php ENDPATH**/ ?>