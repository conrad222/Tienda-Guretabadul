
    
      <footer class="footer text-center">
        <div class="container">
            <div class="row">
                <!-- Footer Location-->
                
                <!-- Footer Social Icons-->
                <div class="col-lg-4 mb-5 mb-lg-0">
                    <a  href="https://www.facebook.com/ekaitz.cormenzana"><i class="fab fa-fw fa-facebook-f fa-2x" id="facebook"></i></a>
                    <a  href="https://twitter.com/Cormen1910"><i class="fab fa-fw fa-twitter fa-2x" id="twitter"></i></a>
                    
                    <a  href="https://www.instagram.com/cormen19/?hl=es"><i class="fab fa-fw fa-instagram fa-2x" id="instagram"></i></a>
                </div>
                <!-- Footer About Text-->
                <div class="col-lg-4">
                    <p id="correo" class="lead mb-0">
                        GURE TABADUL
                        
                    </p>
                </div>
                
            </div>
        </div>
    </footer><?php /**PATH D:\UniServerZ\UniServerZ2\www\GureTabadul\Laravel\resources\views/layout/footer.blade.php ENDPATH**/ ?>