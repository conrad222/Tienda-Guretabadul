
<link rel="stylesheet" href="<?php echo e(URL::asset('scss/footer.css')); ?>">

<footer class="footer text-center">
    <div class="container">
        <div class="row">
            <!-- Footer Location-->

            <!-- Footer Social Icons-->
            <div class="mb-lg-0" style="justify-content:align-center; padding-top: 12px; ">
                <a href="https://www.instagram.com/guretabadul/" style="text-decoration:none; ">instagram<i
                        class="fab fa-fw fa-instagram fa-2x" id="instagram" style="margin-right:50px;"></i></a>
                <a href="https://www.youtube.com/channel/UCiFnpQL4o1KoVfdjr0PM_7w"
                    style="text-decoration:none;">youtube<i class="fab fa-fw fa-youtube fa-2x" id="youtube"
                        style="margin-right:50px;"></i></a>
                <a href="https://www.instagram.com/guretabadul/" style="text-decoration:none;">facebook<i
                        class="fab fa-fw fa-facebook fa-2x" id="facebook" style="margin-right:50px;"></i></a>
                <a href="https://accounts.google.com/signin/v2/identifier?continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&service=mail&sacu=1&rip=1&flowName=GlifWebSignIn&flowEntry=ServiceLogin"
                    style="text-decoration:none;">kaixo@guretabadul.eu<i class="fa-solid fa-at fa-2x" id="gmail"
                        style="margin-right:50px;"></i></a>
                <a href="https://www.google.es/maps/place/Calle+del+Dos+de+Mayo,+48003+Bilbao,+Vizcaya/@43.2573926,-2.9308172,17z/data=!3m1!4b1!4m5!3m4!1s0xd4e4fd23e2b219d:0x69431385f0a72f5c!8m2!3d43.2573887!4d-2.9286285"
                    style="text-decoration:none;">C/ Dos de Mayo, Bilbao<i class="fa-solid fa-location-dot fa-2x"
                        style="margin-right:50px;"></i></i></a>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\Users\Iker\Desktop\UniServerZ\www\Tienda-Guretabadul\TrabajoTiendaPlotters-main\Laravel\resources\views/layout/footer.blade.php ENDPATH**/ ?>