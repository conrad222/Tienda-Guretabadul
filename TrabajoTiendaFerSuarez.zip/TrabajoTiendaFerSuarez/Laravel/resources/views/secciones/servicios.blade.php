@extends('layout.masterpage')
@section('Titulo','Servicios')
@section('contenido')
<h2>Esta es la pagina de servicios</h2>
@endsection