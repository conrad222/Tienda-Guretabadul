
    
      <footer class="footer text-center">
        <div class="container">
            <div class="row">
                <!-- Footer Location-->
                
                <!-- Footer Social Icons-->
                <div class="col-lg-4 mb-5 mb-lg-0">
                   
                    
                    <a  href="https://www.instagram.com/guretabadul/"><i class="fab fa-fw fa-instagram fa-2x" id="instagram"></i></a>
                </div>
                <!-- Footer About Text-->
                <div class="col-lg-4">
                    <p id="correo" class="lead mb-0">
                        GURE TABADUL
                        
                    </p>
                </div>
                
            </div>
        </div>
    </footer><?php /**PATH D:\UniServerZ\www\TrabajoTiendaPlotters\Laravel\resources\views/layout/footer.blade.php ENDPATH**/ ?>