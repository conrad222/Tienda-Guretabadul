<style>
    .nav-link:hover{
        background-color: #B81F57;
        color: white!important;
        border-radius: 20%;
    }
    .nav-link{
        transition: background-color 1s;
        border-radius:20%;
    }
</style><?php /**PATH C:\Users\gorka\Desktop\clase\2DAW\fase4\mikel\UniServerZ\www\TrabajoTiendaPlotters\Laravel\resources\views/layout/estilos.blade.php ENDPATH**/ ?>