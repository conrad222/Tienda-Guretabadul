
<?php $__env->startSection('Titulo','Servicios'); ?>
<?php $__env->startSection('contenido'); ?>
<h2>Esta es la pagina de servicios</h2>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.masterpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\UniServerZ\UniServerZ2\www\GureTabadul\Laravel\resources\views/secciones/servicios.blade.php ENDPATH**/ ?>