
<?php $__env->startSection('Titulo','Servicios'); ?>
<?php $__env->startSection('contenido'); ?>
<h2>Esta es la pagina de nosotros</h2>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.masterpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\marke\Downloads\LiveServer\UniServerZ\www\GureTabadul\Laravel\resources\views/secciones/nosotros.blade.php ENDPATH**/ ?>