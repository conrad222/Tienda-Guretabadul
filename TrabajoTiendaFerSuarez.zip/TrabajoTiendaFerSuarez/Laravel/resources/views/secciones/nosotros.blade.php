@extends('layout.masterpage')
@section('Titulo','Servicios')
@section('contenido')
<h2>Esta es la pagina de nosotros</h2>
@endsection
